package winterschoolone;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface SirenOrderRepository extends PagingAndSortingRepository<SirenOrder, Long>{

}